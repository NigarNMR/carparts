<?php
// Heading
$_['heading_title'] = 'People Online';

// Text
$_['text_view']     = 'View more...';