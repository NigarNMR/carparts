<?php
class ControllerCrossesImport extends Controller {
	private $error = array();

	public function index() {
	
	}

}