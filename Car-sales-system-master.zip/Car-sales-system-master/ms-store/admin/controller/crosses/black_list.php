<?php
class ControllerCrossesBlacklist extends Controller {
	private $error = array();
	
	public function index(){
		
	}
}