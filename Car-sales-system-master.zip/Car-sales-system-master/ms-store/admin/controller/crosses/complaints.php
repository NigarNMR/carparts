<?php
class ControllerCrossesComplaints extends Controller {
	private $error = array();

	public function index() {
	
	}

}